package com.example.parcial2;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.Button;
import android.widget.EditText;

import java.io.BufferedWriter;
import java.net.Socket;

public class MainActivity extends AppCompatActivity {

    private EditText recordatorioET,xET,yET;
    private Button verdeBtn,amarilloBtn,rojoBtn,vistaBtn,confirmarBtn;
    private Socket socket;
    private BufferedWriter writer;
    private boolean verdeIsUp=false;
    private boolean amarilloIsUp=false;
    private boolean rojoIsUp=false;
    private boolean vistaIsUp=false;
    private boolean confirmarIsUp=false;

    @SuppressLint("ClickableViewAccessibility")
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recordatorioET = findViewById(R.id.recordatorioET);
        xET = findViewById(R.id.xET);
        yET = findViewById(R.id.yET);
        verdeBtn = findViewById(R.id.verdeBtn);
        amarilloBtn = findViewById(R.id.amarilloBtn);
        rojoBtn = findViewById(R.id.rojoBtn);
        vistaBtn = findViewById(R.id.vistaBtn);
        confirmarBtn = findViewById(R.id.confirmarBtn);

        ComunicacionTCP comm = new ComunicacionTCP(this);
        comm.solicitarConexion();

        verdeBtn.setOnTouchListener(
                (v, event) -> {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            verdeBtn.setText("DOWN");
                            break;
                        case MotionEvent.ACTION_MOVE:
                            verdeBtn.setText("MOVE");
                            break;
                        case MotionEvent.ACTION_UP:
                            verdeIsUp = true;
                            amarilloIsUp = false;
                            rojoIsUp = false;
                            verdeBtn.setText("UP");
                            break;
                    }
                    return true;
                }
        );

        amarilloBtn.setOnTouchListener(
                (v, event) -> {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            amarilloBtn.setText("DOWN");
                            break;
                        case MotionEvent.ACTION_MOVE:
                            amarilloBtn.setText("MOVE");
                            break;
                        case MotionEvent.ACTION_UP:
                            amarilloIsUp = true;
                            rojoIsUp = false;
                            verdeIsUp = false;
                            amarilloBtn.setText("UP");
                            break;
                    }
                    return true;
                }
        );

        rojoBtn.setOnTouchListener(
                (v, event) -> {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            rojoBtn.setText("DOWN");
                            break;
                        case MotionEvent.ACTION_MOVE:
                            rojoBtn.setText("MOVE");
                            break;
                        case MotionEvent.ACTION_UP:
                            rojoIsUp = true;
                            amarilloIsUp = false;
                            verdeIsUp = false;
                            rojoBtn.setText("UP");
                            break;
                    }
                    return true;
                }
        );

        vistaBtn.setOnTouchListener(
                (v, event) -> {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            rojoBtn.setText("DOWN");
                            break;
                        case MotionEvent.ACTION_MOVE:
                            rojoBtn.setText("MOVE");
                            break;
                        case MotionEvent.ACTION_UP:
                            vistaIsUp = false;
                            confirmarIsUp = true;
                            rojoBtn.setText("UP");
                            break;
                    }
                    return true;
                }
        );

        confirmarBtn.setOnClickListener(
                (v) -> {
                    if (confirmarIsUp == true) {
                        String x = xET.getText().toString();
                        String y = yET.getText().toString();
                        String rec = recordatorioET.getText().toString();
                        if (verdeIsUp == true) {
                            int verco = 255;
                            int amaco = 0;
                            int rojco = 0;
                            String vco = Integer.toString(verco);
                            String aco = Integer.toString(amaco);
                            String rco = Integer.toString(rojco);
                            comm.mandarMesanje(x + ":" + y + ":" + rec + ":" + vco + ":" + aco + ":" + rco);
                        }
                        if (amarilloIsUp == true) {
                            int verco = 255;
                            int amaco = 0;
                            int rojco = 255;
                            String vco = Integer.toString(verco);
                            String aco = Integer.toString(amaco);
                            String rco = Integer.toString(rojco);
                            comm.mandarMesanje(x + ":" + y + ":" + rec + ":" + vco + ":" + aco + ":" + rco);
                        }
                        if (rojoIsUp == true) {
                            int verco = 0;
                            int amaco = 0;
                            int rojco = 255;
                            String vco = Integer.toString(verco);
                            String aco = Integer.toString(amaco);
                            String rco = Integer.toString(rojco);
                            comm.mandarMesanje(x + ":" + y + ":" + rec + ":" + vco + ":" + aco + ":" + rco);
                        }
                        //comm.mandarMesanje(x+":"+y+":"+rec);
                    }
                }
        );

        vistaBtn.setOnTouchListener(
                (v, event) -> {
                    switch (event.getAction()) {
                        case MotionEvent.ACTION_DOWN:
                            rojoBtn.setText("DOWN");
                            break;
                        case MotionEvent.ACTION_MOVE:
                            rojoBtn.setText("MOVE");
                            break;
                        case MotionEvent.ACTION_UP:
                            vistaIsUp = true;
                            confirmarIsUp = false;
                            rojoBtn.setText("UP");
                            break;
                    }
                    return true;
                }
        );

        vistaBtn.setOnClickListener(
                (v)-> {
                    if (vistaIsUp == true) {
                        String x = xET.getText().toString();
                        String y = yET.getText().toString();
                        String rec = recordatorioET.getText().toString();
                        if (verdeIsUp == true) {
                            int verco = 255;
                            int amaco = 0;
                            int rojco = 0;
                            String vco = Integer.toString(verco);
                            String aco = Integer.toString(amaco);
                            String rco = Integer.toString(rojco);
                            comm.mandarMesanje(x + ":" + y + ":" + rec + ":" + vco + ":" + aco + ":" + rco);
                        }
                        if (amarilloIsUp == true) {
                            int verco = 255;
                            int amaco = 0;
                            int rojco = 255;
                            String vco = Integer.toString(verco);
                            String aco = Integer.toString(amaco);
                            String rco = Integer.toString(rojco);
                            comm.mandarMesanje(x + ":" + y + ":" + rec + ":" + vco + ":" + aco + ":" + rco);
                        }
                        if (rojoIsUp == true) {
                            int verco = 0;
                            int amaco = 0;
                            int rojco = 255;
                            String vco = Integer.toString(verco);
                            String aco = Integer.toString(amaco);
                            String rco = Integer.toString(rojco);
                            comm.mandarMesanje(x + ":" + y + ":" + rec + ":" + vco + ":" + aco + ":" + rco);
                        }
                        //comm.mandarMesanje(x+":"+y+":"+rec);
                    }
                }
        );

    }
}

