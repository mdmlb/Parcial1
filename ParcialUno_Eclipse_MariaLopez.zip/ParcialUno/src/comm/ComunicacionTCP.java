package comm;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

import main.Main;
import main.Recordatorio;
import processing.core.PApplet;

public class ComunicacionTCP extends Thread{
	
	private Socket socket;
    private BufferedReader reader;
    private BufferedWriter writer;
    private PApplet p;
    private String line;
    private Main main;    
    
    public ComunicacionTCP(Main main) {
    	this.main=main;
    }

    
    //Hilo de recepcion
    public void run() {
    	try {
    		
			ServerSocket server = new ServerSocket(5000);
			System.out.println("Esperando...");
			this.socket = server.accept();
			System.out.println("Aceptado");
			
			//Reader
			InputStream is = socket.getInputStream();
			InputStreamReader isr = new InputStreamReader(is);
			this.reader=new BufferedReader(isr);
			
			//Wtriter
			OutputStream os = socket.getOutputStream();
			OutputStreamWriter osw = new OutputStreamWriter(os);
			this.writer=new BufferedWriter(osw);
			
			while(true) {
				recibirMensajes();
			}
			
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    //Esperar conexion
    public void esperarConexion(){
    	this.start();
    }

    //Mandar un mensaje
    public void mandarMesanje(String mensaje){
    	new Thread(
    			()->{
    				try {
						writer.write(mensaje+"\n");
						writer.flush();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
    			}
    	).start();
    }

    //Recibir mensajes
    public void recibirMensajes() throws IOException{
    	
    	line = reader.readLine();
    		System.out.println(line);
    		String[] datos = line.split(":");
    		int xp = Integer.parseInt(datos[0]);
        	int yp = Integer.parseInt(datos[1]);
        	String menje = datos[2];
        	int g = Integer.parseInt(datos[3]);
        	int b = Integer.parseInt(datos[4]);
        	int r = Integer.parseInt(datos[5]);
        	
        	//Recordatorio recoo = new Recordatorio(p,xp,yp,menje,r,g,b);
        	
        	main.getRecor().add(new Recordatorio(p,xp,yp,menje,r,g,b));
    	
    }

    //Cerrar conexion
    public void cerrarConexion(){
    	try {
			socket.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

   
	public String getLine() {
		return line;
	}

	public void setLine(String line) {
		this.line = line;
	}
	
	
	
}
