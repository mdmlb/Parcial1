package main;

import java.util.ArrayList;

import comm.ComunicacionTCP;
import processing.core.PApplet;

public class Main extends PApplet{
	
	ComunicacionTCP comm;
	ArrayList<Recordatorio> recor; 

	public static void main(String[] args) {
		PApplet.main("main.Main");

	}

	public void settings() {
		size(500,500);
	}
	
	public void setup() {
		
		recor = new ArrayList<Recordatorio>();
		comm = new ComunicacionTCP(this);
		comm.esperarConexion();
		
	}
	
	public void draw() {
		background(255);
		
		if(recor != null) {
			for (int i = 0; i < recor.size(); i++) {
				recor.get(i).pintar(this);
			}
		}
		
	}

	public ComunicacionTCP getComm() {
		return comm;
	}

	public void setComm(ComunicacionTCP comm) {
		this.comm = comm;
	}

	public ArrayList<Recordatorio> getRecor() {
		return recor;
	}

	public void setRecor(ArrayList<Recordatorio> recor) {
		this.recor = recor;
	}
	
	
	
}
