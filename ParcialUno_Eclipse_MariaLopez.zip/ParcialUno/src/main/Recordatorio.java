package main;

import processing.core.PApplet;

public class Recordatorio {

	private int x,y,r,g,b;
	private String mens;
	private PApplet p;
	

	public Recordatorio(PApplet p, int x, int y, String mens, int r, int g, int b) {
		this.p=p;
		this.x=x;
		this.y=y;
		this.mens=mens;
		this.r=r;
		this.g=g;
		this.b=b;
		
	}
	
	public void pintar(PApplet p) {
		p.fill(r,g,b);
		p.ellipse(x, y, 25, 25);
		p.fill(0);
		p.text(mens, x - 10 , y + 25);
	}	
	
}
